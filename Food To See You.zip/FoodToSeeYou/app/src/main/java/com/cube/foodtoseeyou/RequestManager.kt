package com.cube.foodtoseeyou

class RequestManager {

}